﻿using System;
namespace ReExample;
public class SearchAttribute:Attribute
{
    public MatchTypes Match { get; set; }
    public SearchAttribute()
    {
        Match = MatchTypes.Full;
    }
<<<<<<< HEAD
    public SearchAttribute(string match)
    {
        Match = match;
=======
    public SearchAttribute(MatchTypes matchType)
    {
        Match = matchType;
>>>>>>> 93eadfb01816dd074429d686f730576aad1a1bb6
    }
}
public enum MatchTypes
{
    Full,
    StartsWith,
    EndsWith,
    Contains
}