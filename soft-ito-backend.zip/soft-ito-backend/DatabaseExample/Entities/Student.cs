﻿using System;
namespace DatabaseExample.Entities
{
	public class Student
	{
		public Guid Id { get; set; }
		public Guid UserId { get; set; }
		string Plate { get; set; }
		byte Marks { get; set; }
		byte Absenteeism { get; set; }
        public virtual User User { get; set; }
    }
}


