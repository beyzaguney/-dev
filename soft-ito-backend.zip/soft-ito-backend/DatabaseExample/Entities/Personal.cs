﻿using System;
namespace DatabaseExample.Entities
{
	public class Personal
	{
		public Guid Id { get; set; }
		public Guid UsserId { get; set; }
		decimal Salary { get; set; }
		string SSN { get; set; }
        public virtual User User { get; set; }
    }
}


