﻿using System;
namespace DatabaseExample.Entities
{
	public class Jobber
	{
		public Guid Id { get; set; }
		public Guid UserId { get; set; }
		string Plate { get; set; }
		string WorkArea { get; set; }
        public virtual User User { get; set; }
    }
}


